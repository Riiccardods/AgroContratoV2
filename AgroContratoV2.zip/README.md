# AgroContratoV2

Contrato inteligente para controle de assinaturas empresariais com renovação por dias extras e consulta de comprovante na blockchain (Kaleido).
